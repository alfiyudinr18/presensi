@extends('front.app')

@section('content')
    <div id="isi"></div>
@endsection