<?php if(!empty($cek)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-12">
    <label class="col-sm-2 col-form-label" for="">RFID</label>
    <div class="col-sm-10">
        <input type="text" name="uid" value="<?php echo e($item->uid); ?>" class="form-control" required readonly>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
<?php else: ?>
<div class="row mb-12">
    <label class="col-sm-2 col-form-label" for="">RFID</label>
    <div class="col-sm-10">
        <input type="text" name="uid" class="form-control" required readonly placeholder="Tempelkan kartu ke RFID"> 
    </div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\presensi_csa\resources\views/anggota/kartu.blade.php ENDPATH**/ ?>