

<?php $__env->startSection('content'); ?>
    <div id="isi"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\presensi_csa\resources\views/front/index.blade.php ENDPATH**/ ?>